import React, { useEffect, useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area, PieChart, Pie, Cell 
} from 'recharts';
import { 
  ComposableMap, 
  Geographies, 
  Geography, 
  Marker 
} from 'react-simple-maps';
import { 
  TrendingUp, 
  Users, 
  MousePointer2, 
  Clock, 
  Globe, 
  ArrowUpRight, 
  ArrowDownRight,
  Zap,
  Download,
  BarChart3
} from 'lucide-react';
import { collection, query, limit, onSnapshot, orderBy, where, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { motion } from 'motion/react';

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

export default function AnalyticsOverview() {
  const [activeSessions, setActiveSessions] = useState<any[]>([]);
  const [chartData, setChartData] = useState<any[]>([]);
  const [pieData, setPieData] = useState<any[]>([]);
  const [deviceData, setDeviceData] = useState<any[]>([]);
  const [referralData, setReferralData] = useState<any[]>([]);
  const [countryData, setCountryData] = useState<any[]>([]);
  const [toolConversions, setToolConversions] = useState<any[]>([]);
  const [timeRange, setTimeRange] = useState(7); // days
  const [stats, setStats] = useState({
    totalVisits: 0,
    uniqueVisitors: 0,
    activeNow: 0,
    avgDuration: '0s',
    interaction: '0%',
    bounceRate: '0%'
  });

  const COLORS = ['#6366f1', '#60a5fa', '#34d399', '#f472b6', '#8b5cf6'];

  useEffect(() => {
    // 1. Live Sessions (Real-time updates)
    const fifteenMinsAgo = new Date(Date.now() - 15 * 60 * 1000);
    const sessionsQ = query(
      collection(db, 'active_sessions'),
      where('lastActive', '>=', Timestamp.fromDate(fifteenMinsAgo)),
      orderBy('lastActive', 'desc')
    );

    const unsubscribeSessions = onSnapshot(sessionsQ, (snapshot) => {
      const sessions = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setActiveSessions(sessions);
      setStats(prev => ({ ...prev, activeNow: sessions.length }));
    });

    // 2. Aggregate Data based on Time Range
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - timeRange);
    
    const eventsQ = query(
      collection(db, 'analytics_events'),
      where('timestamp', '>=', Timestamp.fromDate(startDate)),
      orderBy('timestamp', 'asc')
    );

    const unsubscribeEvents = onSnapshot(eventsQ, (snapshot) => {
      const events = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
      // Calculate Base Metrics
      const totalVisits = events.length;
      const uniqueSessions = new Set(events.map((e: any) => e.sessionId)).size;
      const uniqueVisitors = new Set(events.map((e: any) => e.userId)).size;
      
      // GROUP BY SESSION for advanced metrics
      const sessionsMap: any = {};
      events.forEach((event: any) => {
        const sid = event.sessionId || event.userId || event.id; // fallback
        if (!sessionsMap[sid]) sessionsMap[sid] = [];
        sessionsMap[sid].push(event);
      });

      const sessionList = Object.values(sessionsMap);
      
      // Bounce Rate: sessions with only 1 page view / total sessions
      const singlePageSessions = sessionList.filter((s: any) => s.length === 1).length;
      const bounceRate = uniqueSessions > 0 ? (singlePageSessions / uniqueSessions * 100).toFixed(1) : 0;

      // Avg Duration
      let totalDurationMs = 0;
      sessionList.forEach((s: any) => {
        if (s.length > 1) {
          const start = s[0].timestamp?.toMillis() || 0;
          const end = s[s.length - 1].timestamp?.toMillis() || 0;
          totalDurationMs += (end - start);
        }
      });
      const avgDurationSec = uniqueSessions > 0 ? (totalDurationMs / uniqueSessions / 1000) : 0;
      const formatDuration = (sec: number) => {
        if (sec < 60) return `${Math.round(sec)}s`;
        const mins = Math.floor(sec / 60);
        const rem = Math.round(sec % 60);
        return `${mins}m ${rem}s`;
      };

      // Engagement Rate: (total sessions - bounce sessions) / total sessions
      const engagementRate = uniqueSessions > 0 ? ((uniqueSessions - singlePageSessions) / uniqueSessions * 100).toFixed(1) : 0;

      setStats(prev => ({ 
        ...prev, 
        totalVisits, 
        uniqueVisitors,
        bounceRate: `${bounceRate}%`,
        avgDuration: formatDuration(avgDurationSec),
        interaction: `${engagementRate}%`
      }));

      // Process Time-Series Chart Data
      const timeData: any = {};
      // Initialize time slots
      for (let i = timeRange - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const label = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
        timeData[label] = { visits: 0, unique: 0 };
      }

      events.forEach((event: any) => {
        const date = event.timestamp?.toDate();
        if (date) {
          const label = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
          if (timeData[label]) {
            timeData[label].visits++;
          }
        }
      });
      
      // Mark unique per day (simplified)
      const daySessions: any = {};
      events.forEach((event: any) => {
         const date = event.timestamp?.toDate();
         if (date) {
           const label = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
           if (!daySessions[label]) daySessions[label] = new Set();
           daySessions[label].add(event.sessionId);
         }
      });
      Object.keys(daySessions).forEach(label => {
        if (timeData[label]) timeData[label].unique = daySessions[label].size;
      });

      const formattedTimeSeries = Object.keys(timeData).map(label => ({
        name: label,
        visits: timeData[label].visits,
        unique: timeData[label].unique
      }));
      setChartData(formattedTimeSeries);

      // Process Device Distribution
      const devicesGroup: any = { Desktop: 0, Mobile: 0, Tablet: 0 };
      events.forEach((e: any) => {
        const dev = e.device || 'Desktop';
        devicesGroup[dev] = (devicesGroup[dev] || 0) + 1;
      });
      setDeviceData(Object.keys(devicesGroup).map(name => ({ name, value: devicesGroup[name] })));

      // Process Referral Sources
      const referrals: any = {};
      events.forEach((e: any) => {
        const ref = e.referrer || 'Direct';
        const cleanRef = ref.includes('localhost') ? 'Development' : ref.split('/')[2] || 'Direct';
        referrals[cleanRef] = (referrals[cleanRef] || 0) + 1;
      });
      setReferralData(Object.keys(referrals).sort((a,b) => referrals[b] - referrals[a]).slice(0, 5).map(name => ({ name, value: referrals[name] })));

      // Process Countries
      const countries: any = {};
      events.forEach((e: any) => {
        const c = e.location?.country || 'Unknown';
        countries[c] = (countries[c] || 0) + 1;
      });
      setCountryData(Object.keys(countries).sort((a,b) => countries[b] - countries[a]).slice(0, 5).map(name => ({ name, value: countries[name] })));

      // Process Tool Conversions
      const conversions: any = { instagram: 0, tiktok: 0, 'text-box': 0, other: 0 };
      events.forEach((e: any) => {
        if (e.type === 'conversion' && e.tool) {
          conversions[e.tool] = (conversions[e.tool] || 0) + 1;
        }
      });
      setToolConversions(Object.keys(conversions).map(name => ({ name, value: conversions[name] })));

      // Process Page performance (Tool usage)
      const toolMap: any = {};
      events.forEach((event: any) => {
        const path = event.path || 'Unknown';
        if (event.type === 'page_view') {
          toolMap[path] = (toolMap[path] || 0) + 1;
        }
      });

      const formattedPie = Object.keys(toolMap)
        .sort((a, b) => toolMap[b] - toolMap[a])
        .slice(0, 5)
        .map(name => ({
          name: name === '/' ? 'Home' : name.replace('/', ''),
          value: toolMap[name]
        }));
      setPieData(formattedPie);
    });

    return () => {
      unsubscribeSessions();
      unsubscribeEvents();
    };
  }, [timeRange]);

  return (
    <div className="space-y-8 pb-20">
      {/* Filters (same as before) */}

      {/* ... keep top stats ... */}

      {/* ... keep main charts ... */}

      {/* Distribution Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <div className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm">
           <h3 className="text-lg font-black text-slate-900 mb-6">Top Pages</h3>
           <div className="space-y-4">
              {pieData.map((item, idx) => (
                <div key={item.name} className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest">
                    <span className="text-slate-500 truncate max-w-[120px]">{item.name}</span>
                    <span className="text-indigo-600">{item.value}</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-50 rounded-full overflow-hidden">
                    <motion.div initial={{width: 0}} animate={{width: `${(item.value / stats.totalVisits) * 100}%`}} className="h-full bg-indigo-600 rounded-full" />
                  </div>
                </div>
              ))}
           </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm">
           <h3 className="text-lg font-black text-slate-900 mb-6">Referrals</h3>
           <div className="space-y-4">
              {referralData.map((item, idx) => (
                <div key={item.name} className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest">
                    <span className="text-slate-500 truncate max-w-[120px]">{item.name}</span>
                    <span className="text-slate-400">{item.value}</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-50 rounded-full overflow-hidden">
                    <motion.div initial={{width: 0}} animate={{width: `${(item.value / stats.totalVisits) * 100}%`}} className="h-full bg-blue-500 rounded-full" />
                  </div>
                </div>
              ))}
           </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm">
           <h3 className="text-lg font-black text-slate-900 mb-6">Countries</h3>
           <div className="space-y-4">
              {countryData.map((item, idx) => (
                <div key={item.name} className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest">
                    <span className="text-slate-500 truncate max-w-[120px]">{item.name}</span>
                    <span className="text-slate-400">{item.value}</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-50 rounded-full overflow-hidden">
                    <motion.div initial={{width: 0}} animate={{width: `${(item.value / stats.totalVisits) * 100}%`}} className="h-full bg-green-500 rounded-full" />
                  </div>
                </div>
              ))}
           </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm">
           <h3 className="text-lg font-black text-slate-900 mb-4">Devices</h3>
           <div className="h-[120px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={deviceData} cx="50%" cy="50%" innerRadius={35} outerRadius={50} paddingAngle={5} dataKey="value">
                    {deviceData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
           </div>
           <div className="flex flex-wrap gap-2 mt-4">
              {deviceData.map((item, idx) => (
                <div key={item.name} className="flex items-center gap-1.5 px-2 py-1 bg-slate-50 rounded-lg">
                  <div className="w-2 h-2 rounded-full" style={{backgroundColor: COLORS[idx]}} />
                  <span className="text-[8px] font-black text-slate-500 uppercase tracking-tighter">{item.name}</span>
                </div>
              ))}
           </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
         <div className="flex items-center justify-between mb-8">
            <div>
               <h3 className="text-xl font-black text-slate-900 tracking-tight">Tool Conversions</h3>
               <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Asset Exports by Platform</p>
            </div>
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
               <Download size={20} />
            </div>
         </div>
         <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {toolConversions.map((tool) => (
               <div key={tool.name} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-center">
                  <p className="text-2xl font-black text-slate-900">{tool.value}</p>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">{tool.name}</p>
               </div>
            ))}
         </div>
      </div>

      <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm overflow-hidden">
         <div className="flex items-center justify-between mb-8">
            <div>
               <h3 className="text-xl font-black text-slate-900 tracking-tight">Active Live Stream</h3>
               <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Real-time visitor activity</p>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 bg-green-50 text-green-600 rounded-full text-[10px] font-black uppercase">
               <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" /> Live Now
            </div>
         </div>
         <div className="overflow-x-auto">
            <table className="w-full">
               <thead>
                  <tr className="text-left border-b border-slate-100">
                     <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest font-black">Visitor ID</th>
                     <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest font-black">Location</th>
                     <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest font-black">Device</th>
                     <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest font-black">Current Page</th>
                     <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest font-black">Last Active</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                  {activeSessions.map(session => (
                    <tr key={session.id} className="group hover:bg-slate-50 transition-colors">
                       <td className="py-4">
                          <div className="flex items-center gap-3">
                             <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-xs uppercase">
                                {session.id.substring(0, 1)}
                             </div>
                             <span className="text-xs font-bold text-slate-600">{session.id.substring(0, 12)}...</span>
                          </div>
                       </td>
                       <td className="py-4">
                          <div className="flex items-center gap-2">
                             <span className="text-xs font-black text-slate-900 tracking-tight">{session.location?.city || 'Unknown'}</span>
                             <span className="text-[10px] font-bold text-slate-400 uppercase">{session.location?.countryCode || 'UN'}</span>
                          </div>
                       </td>
                       <td className="py-4 text-xs font-black text-slate-500 uppercase">{session.device || 'Desktop'}</td>
                       <td className="py-4">
                          <span className="px-2 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-black rounded-lg border border-indigo-100">
                             {session.path || '/'}
                          </span>
                       </td>
                       <td className="py-4 text-xs font-medium text-slate-400">
                          Just now
                       </td>
                    </tr>
                  ))}
                  {activeSessions.length === 0 && (
                    <tr>
                       <td colSpan={5} className="py-20 text-center">
                          <p className="text-xs font-bold text-slate-300 uppercase italic">No active visitors right now</p>
                       </td>
                    </tr>
                  )}
               </tbody>
            </table>
         </div>
      </div>
    </div>
  );
}
